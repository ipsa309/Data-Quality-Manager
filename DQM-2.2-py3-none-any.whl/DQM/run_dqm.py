import pandas as pd
import numpy as np
import datetime
import time
from pyspark.sql.types import *
from pyspark.sql.functions import *
import string
import requests
from pyspark.sql.functions import lit, col, create_map
from itertools import chain
from pyspark.dbutils import DBUtils
import cryptohash,re
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from DQM.dqm import DQM

class run_DQM:
  def fn_parse_operator_value(self,value):
    out={}
    if value !='':
      value=value.split(',')
      if len(value)==1:
        out['input_value']=re.sub('[^0-9.-]','',value[0])
        out['input_operator']=re.sub('[0-9.-]','',value[0])
        out['count']= 1 if out['input_value']!='' and out['input_operator']!='' else  0
      elif len(value)==2:
        out['input_value']=[re.sub('[^0-9.-]','',value[0]),re.sub('[^0-9.-]','',value[1])]
        out['input_operator']=[re.sub('[0-9.-]','',value[0]),re.sub('[0-9.-]','',value[1])]
        out['count']=2 if out['input_value'][0]!='' and out['input_operator'][0]!='' else  0
    #print(out)
    return out
  def fn_get_rgbcondition(self,pass_threshold,msg,positive_negative=None):
      conditon=''
      out=self.fn_parse_operator_value(pass_threshold)
      if positive_negative == None:
        if out['count']==1:
          conditon=f"if value {out['input_operator']} {out['input_value']} : \r\n\tstatus='{msg}'\r\n"
        elif out['count']==2:
          conditon=f"if value {out['input_operator'][0]} {out['input_value'][0]} and value {out['input_operator'][1]} {out['input_value'][1]} :\r\n\tstatus='{msg}'\r\n"
      else:
        positive_negative=positive_negative.split(',')
        if '+' in positive_negative and '-' not in positive_negative:
          if out['count']==1:
            conditon=f"if value {out['input_operator']} {out['input_value']} : \r\n\tstatus='{msg}'\r\n"
          elif out['count']==2:
            conditon=f"if value {out['input_operator'][0]} {out['input_value'][0]} and value {out['input_operator'][1]} {out['input_value'][1]} :\r\n\tstatus='{msg}'\r\n"
        elif '-' in positive_negative and '+' not in positive_negative:
          if out['count']==1:
            conditon=f"if value {out['input_operator']} -{out['input_value']} : \r\n\tstatus='{msg}'\r\n"
          elif out['count']==2:
            conditon=f"if value {out['input_operator'][0]} -{out['input_value'][0]} and value {out['input_operator'][1]} -{out['input_value'][1]} :\r\n\tstatus='{msg}'\r\n"
        elif '-' in positive_negative and '+' in positive_negative:
          if out['count']==1:
            opt_reverse=out['input_operator']
            #if len(opt_reverse)==2 and opt_reverse.count('=')<2:
            if '<' in opt_reverse:
              opt_reverse=opt_reverse.replace('<','>')
            else:
              opt_reverse=opt_reverse.replace('>','<')
            conditon=f"if value {opt_reverse} -{out['input_value']} and value {out['input_operator']} {out['input_value']} : \r\n\tstatus='{msg}'\r\n"
          elif out['count']==2:
            conditon=f"if (value {out['input_operator'][0]} -{out['input_value'][0]} and value {out['input_operator'][1]} -{out['input_value'][1]}) or (value {out['input_operator'][0]} {out['input_value'][0]} and value {out['input_operator'][1]} {out['input_value'][1]}) :\r\n\tstatus='{msg}'\r\n"
      return conditon
    
  
  def __init__(self,file_path,QC_table,table_base_path,format,sheet_name='Cleans',read_type='full'):
      spark=SparkSession.getActiveSession()
      self.schema = StructType([StructField('batch_id',StringType(), True),
                        StructField('run_id',StringType(), True),
                        StructField('layer',StringType(), True),
                        StructField('source',StringType(), True),
                        StructField('table_name',StringType(), True),
                        StructField('check_type',StringType(), True),
                      StructField('DQM_Type',StringType(), True),
                      StructField('DQM_On',StringType(), True),
                      StructField('observed_value',StringType(), True),
                      StructField('difference',StringType(), True),
                      StructField('run_time',StringType(), True),
                      StructField('time_taken',StringType(), True),
                      StructField('qc_run',StringType(), True),
                      StructField('qc_run_error',StringType(), True),
                      StructField('qc_status',StringType(), True),
                      StructField('qc_error',StringType(), True),
                      StructField('threshold_status',StringType(), True),
                      StructField('criticality',StringType(), True),
                      StructField('alert_flag',StringType(), True)])
      self.keys=['batch_id',
                 'run_id',
                 'layer',
                 'source',
                 'table_name',
                 'check_type',
                 'DQM_Type',
                 'DQM_On',
                 'observed_value',
                 'difference',
                 'run_time',
                 'time_taken',
                 'qc_run',
                 'qc_run_error',
                 'qc_status',
                 'qc_error',
                 'threshold_status',
                 'criticality',
                 'alert_flag']
      #'/mnt/cdw_maestrodl/lob/damcoffw/poc/QC_TABLE'
      #/mnt/cdw_maestro_proddl/lob/damcoffw/tmff/
      try:
        _=spark.read.format('delta').load(QC_table)
        print("Qc table is already present ")
      except:
        print("Qc table is not exits. Creating new one")
        df = spark.createDataFrame(data=[],schema = self.schema)
        df.write.format('delta').save(QC_table)

      DQM_checks_input=pd.read_excel(file_path, sheet_name=sheet_name)
      d=(DQM_checks_input.iloc[:2].T)
      d.reset_index(inplace=True)
      d['index']=d['index'].apply(lambda x : np.nan if str(x).startswith('Unnamed:') else x)
      d.fillna(method='ffill', inplace=True)
      
      #error_log_file=open("/dbfs/cdw_maestrodl/lob/damcoffw/poc/error_log.log","w")
      
      DQM_checks_input=DQM_checks_input[2:]
      DQM_checks_input.columns=(d.apply(lambda x : (str(x['index'])+'_'+str(x[0])+'_'+str(x[1])).replace('_nan','').replace('nan_','').strip().replace(' ','_').replace('?','').replace('(','').replace(')','').lower(),axis=1).to_list())

      DQM_checks_input['source'].ffill(inplace=True)
      DQM_checks_input['layer'].ffill(inplace=True)
      DQM_checks_input=DQM_checks_input.T.drop_duplicates().T
      checks_columns=pd.unique([x for x in DQM_checks_input.columns if x.startswith('conformity') or x.startswith('consistency')]).tolist()

      DQM_checks_input.dropna(how='all',subset=checks_columns,inplace=True)
      DQM_checks_input[DQM_checks_input['check_is_required'].str.lower()=='y']
      data=(DQM_checks_input.groupby(['source','layer','tables/files']).columns.agg([('count', 'count'), ('primary_key', ', '.join)])).reset_index()
      data['primary_key']=data.apply(lambda x : ','.join([i.split(':')[0].strip() for i in x['primary_key'].split(',')]), axis=1)
      DQM_checks_input=DQM_checks_input.merge(data, on=['source','layer','tables/files'],how='inner').drop(['primary_key_x','count'],axis=1).rename(columns={'primary_key_y':'primary_key'})
      
      
      list_1=[]
      layer=''
      source=''
      for x in DQM_checks_input.iterrows():
        tmp=dict(x[1])
        list_1.append('{'+f'"source":"{tmp["source"]}","layer":"{tmp["layer"]}","tables":"{tmp["tables/files"]}","primary_key":"{tmp["primary_key"]}"'+'}')
        layer=tmp["source"]
        source=tmp["layer"]
        
      batch_id=cryptohash.md5(str(str(str(datetime.datetime.now())[:10])+layer+source))#.encode('utf-8'))
      run_id=cryptohash.md5(str(str(str(datetime.datetime.now())[:19])+layer+source))#.encode('utf-8'))
      
      #return batch_id,run_id

      list_2=[]
      for x in set(list_1):
        tmp=eval(x)
        obj='{'+f'"object_code":"DQM(layer=\'{tmp["layer"]}\'\
               ,source=\'{tmp["source"]}\'\
               ,table_path=\'{table_base_path}{tmp["tables"]}\'\
               ,format=\'{format}\'\
              ,qc_table=\'{QC_table}_{run_id}\'\
              ,batch_id=\'{batch_id}\'\
              ,run_id=\'{run_id}\'\
              ,primary_key=\'{tmp["primary_key"]}\'\
              ,read_type=\'{read_type}\')","tables":"{tmp["source"]}|{tmp["layer"]}|{tmp["tables"]}"'+'}';
        list_2.append(obj)


      checks=[]
      fail_qc=[]
      #return DQM_checks_input,checks_columns
      for j in DQM_checks_input['tables/files'].unique():
        for x in DQM_checks_input[DQM_checks_input['tables/files']==j].iterrows():
          tmp=dict(x[1])
          for z in checks_columns:
            if str(tmp[z]) != 'nan':
              try:
                input_dict=eval(str('{'+re.sub('\r?\n','',str(tmp[z]).lower())+'}'))
                #print(input_dict)
                condition=''
                pos_neg=input_dict['threshold_condition'] if not(input_dict.get('threshold_condition') is None) else None
                if input_dict['active_flag'] == 'y' and input_dict['pass_threshold'] != '' :
                  pass_threshold=input_dict['pass_threshold']
                  condition=self.fn_get_rgbcondition(pass_threshold,msg='GREEN',positive_negative=pos_neg)
                if input_dict['active_flag'] == 'y' and input_dict['yellow_threshold'] != '' :
                  yellow_threshold=input_dict['yellow_threshold']
                  condition+='el'+self.fn_get_rgbcondition(yellow_threshold,msg='YELLOW',positive_negative=pos_neg)
                if input_dict['active_flag'] == 'y' and input_dict['red_threshold'] != '' :
                  red_threshold=input_dict['red_threshold']
                  condition+='el'+self.fn_get_rgbcondition(red_threshold,msg='RED',positive_negative=pos_neg)
                condition+='else:\r\n\tstatus=\'error\''
                #print(condition,'\r\n')
                filter_check_dict={"table_name":j,
                                   "parameter":input_dict['parameter'],
                                   "agg_parameter": input_dict['agg_parameter'] if not(input_dict.get('agg_parameter') is None) else "",
                                   "window_parameter": input_dict['window_parameter'] if not(input_dict.get('window_parameter') is None) else "",
                                   "filter_column":input_dict['filter_column'],
                                         "column":tmp["columns"],
                                         "check_name":z,
                                         "condition":"''\r\n"+condition+"\r\n''",
                                         "active_flag":input_dict['active_flag'],
                                         "criticality":str(input_dict['criticality']).upper(),
                                         "table_key":tmp["source"]+'|'+tmp["layer"]+'|'+j
                                        }
                checks.append(filter_check_dict);
              except Exception as e:
                #error_log_file.writelines(str([str(e),str(z),str(tmp[z])]))
                fail_qc.append({'column':z,'wrong_json':str(tmp[z]),'error':str(e)})
                print("Json is not in well form\n",e,'\n',z,'\n',tmp[z])
                #print(e,"json is not in well form"
      #print(''+str(checks)+'\n\n-------------------------------------------------------------\n\n')
      #error_log_file.close()
      
      if 1==1:
        print('+++++++++++++++++++++++++++++++++')
        print('QC config file Parse summary')
        print(f"Total QC : {len(checks)+len(fail_qc)}")
        print(f"Validation Pass : {len(checks)}")
        print(f"Validation Fail : {len(fail_qc)}")
        print('+++++++++++++++++++++++++++++++++')
        #input(f"\nThere are some errors in config file do you want to continue")
      
      list_4={};
      for x in checks:
        tmp=''
        x_tmp=x
        if x_tmp['active_flag'] == 'y':
          if x_tmp['check_name'].startswith('conformity'):
            column=x_tmp['column'].split(':')[0].strip()
            column= column if column=='*' else '`'+column+'`'

            if x_tmp['check_name'].endswith('data_type'):
              condition=f"''\r\nif value == '{x_tmp['parameter']}':\r\n\tstatus='green' \r\nelse: \r\n\tstatus='red'\r\n''"
              tmp=f"fn_checkDatatype(column='{column}',filtercondition=None,rgb_condition='{condition}',check_type='conformity',criticality='{x_tmp['criticality']}')"

            elif x_tmp['check_name'].endswith('null'):
              filtercondition=f"{column} is {x_tmp['parameter']}"
              tmp=f"fn_checkMissingValue(column='{column}',filtercondition='{filtercondition}',rgb_condition='{x_tmp['condition']}',check_type='conformity',criticality='{x_tmp['criticality']}')"

            elif x_tmp['check_name'].endswith('length'):
              out=self.fn_parse_operator_value(x_tmp['parameter'])
              if out['count']==1:
                filtercondition=f"length({column}) {out['input_operator']} {out['input_value']}"
              elif out['count']==2:
                filtercondition=f"length({column}) between {eval(out['input_value'][0])} and {eval(out['input_value'][1])}"

              tmp=f"fn_checkLength(column='{column}',filtercondition='{filtercondition}',rgb_condition='{x_tmp['condition']}',check_type='conformity',criticality='{x_tmp['criticality']}')"

            elif x_tmp['check_name'].endswith('value_range'):
              out=str(x_tmp['parameter'].split(',')).replace('[','(').replace(']',')')
              filtercondition=f'"lower({column}) not in {out}"'
              tmp=f"fn_checkValueRange(column='{column}',filtercondition={filtercondition},rgb_condition='{x_tmp['condition']}',check_type='conformity',criticality='{x_tmp['criticality']}')"

            elif x_tmp['check_name'].endswith('completeness'):
              filtercondition=f"{column} is not {x_tmp['parameter']} or replace({column},\' \',\'\') != \'\'"
              tmp=f"fn_checkCompleteness(column='{column}',filtercondition=\"{filtercondition}\",rgb_condition='{x_tmp['condition']}',check_type='conformity',criticality='{x_tmp['criticality']}')"

            elif x_tmp['check_name'].endswith('min_value'):
              tmp=''

            elif x_tmp['check_name'].endswith('max_value'):
              tmp=''

            elif x_tmp['check_name'].endswith('negative'):
              tmp=''

            elif x_tmp['check_name'].endswith('uniqueness'):
              tmp=f"fn_checkCountDistinct(column='{column}',filter_condition=None,rgb_condition='{x_tmp['condition']}',check_type='conformity',criticality='{x_tmp['criticality']}')"

            elif x_tmp['check_name'].endswith('custom_query'):
              tmp=f"fn_customQualityCheck(sql_query='{x_tmp['parameter']}',rgb_condition='{x_tmp['condition']}',criticality='{x_tmp['criticality']}')"

          elif x_tmp['check_name'].startswith('consistency'): 
            column=x_tmp['column'].split(':')[0].strip()
            column= column if column=='*' else '`'+column+'`'
            filter_column=x_tmp['filter_column'] if x_tmp['filter_column']=='*' else '`'+x_tmp['filter_column']+'`'
            column=filter_column if filter_column=='*' else column

            if x_tmp['check_name'].endswith('table_level'):
                if '_count_' in x_tmp['check_name']:
                  tmp=f"fn_checkCount(check_type='consistency')"
                elif '_trend_' in x_tmp['check_name']:

                  filtercondition=f"select {x_tmp['agg_parameter']}({filter_column}) from ? "
                  tmp=f"fn_checkValueTrend(column='{column}',filtercondition='''\r\n{filtercondition}\r\n''',rgb_condition='{x_tmp['condition']}',window_parameter='{x_tmp['window_parameter']}',check_type='consistency',criticality='{x_tmp['criticality']}')"

                elif '_average_' in x_tmp['check_name']:
                  tmp=''
                elif '_outlier_' in x_tmp['check_name']:
                  tmp=''
            elif x_tmp['check_name'].endswith('column_level'):
                if '_count_' in x_tmp['check_name']:
                  tmp=f"fn_checkCount(column='{column}',condition='{x_tmp['condition']}',check_type='consistency')"
                elif '_trend_' in x_tmp['check_name']:
                  filtercondition=f"select {x_tmp['agg_parameter']}({filter_column}) from ? "
                  tmp=f"fn_checkValueTrend(column='{column}',filtercondition='''\r\n{filtercondition}\r\n''',rgb_condition='{x_tmp['condition']}',window_parameter='{x_tmp['window_parameter']}',check_type='consistency',criticality='{x_tmp['criticality']}')"
                elif '_average_' in x_tmp['check_name']:
                  tmp=f"fn_checkAverage(column='{column}',condition='{x_tmp['condition']}',check_type='consistency')"
                elif '_outlier_' in x_tmp['check_name']:
                  tmp=f"fn_checkCount(column='{column}',condition='{x_tmp['condition']}',check_type='consistency')"

          if(tmp!=''):
            if x_tmp['table_key'] in list_4:
              old=list_4[x_tmp['table_key']]
              old.append(tmp)
              list_4[x_tmp['table_key']]=old
            else:
              list_4[x_tmp['table_key']]=[tmp]       
     
      list_5={}
      for x in list_2:
        tmp=eval(x)
        table_key=tmp['tables']
        if table_key in list_4.keys():
          new='obj='+tmp['object_code']
          for y in list_4[table_key]:
            new+='\r\nobj.'+y
          if table_key in list_5:
            old=list_5[table_key]
            old.append(new)
            list_5[table_key]=old
          else:
            list_5[table_key]=[new]
      #return list_5
      for key,val in list_5.items():
        print("checks running on ",key)
        total=len(val)
        print(total)
        i=0
        for x in val:
          #print('#---------------------------------------------------------\n',x,'\n#---------------------------------------------------\n')
          exec(x)
          #print(f"INFO : {x.split('.')[1]} is done\n")
          i=i+1
          print(f"{i/total}% done\n")
      self.table_info=QC_table+'_'+run_id,QC_table
    
  def __str__(self):
    return str(self.table_info)
