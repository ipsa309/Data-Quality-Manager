import pandas as pd
import numpy as np
import datetime
import time
from pyspark.sql.types import *
from pyspark.sql.functions import *
import string
import requests
from pyspark.sql.functions import lit, col, create_map
from itertools import chain
from pyspark.dbutils import DBUtils
import cryptohash,re
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

class DQM:
  '''
  
  Initiate DQM class with passing requied field
  
  layer : This is data layer like raw,cleans etc
  source : source of data like TMFF, more etc
  table_path : Table path which is use to run qc
  format : format of table like delta, orc etc
  qc_table : give location for storing qc result
  
  example :

  dqm= DQM(layer='lob'
         ,source='tmff'
         ,table_path='/mnt/cdw_maestro_proddl/lob/damcoffw/tmff/tmff_cdw_job'
         ,format='delta'
        ,qc_table='/mnt/cdw_maestrodl/lob/damcoffw/poc/QC_TABLE')
        
  '''
  
  def __init__(self,layer,source,table_path,format,qc_table,batch_id,run_id,primary_key,read_type):
    self.spark=SparkSession.getActiveSession()
    self.batch_id=batch_id
    self.run_id=run_id
    self.read_type=read_type
    self.primary_key=primary_key
    self.layer=layer
    self.source=source
    self.table_name=self.fn_getTableName(table_path).split('.')[0]
    #print(self.table_name)
    self.data= self.fn_readData(table_path,format,read_type)
    self.view_name="DQM_"+self.table_name+"_view"
    self.qc_table=qc_table
    #self.dutils=DBUtils(SparkSession.getActiveSession())
    self.schema = StructType([StructField('batch_id',StringType(), True),
                      StructField('run_id',StringType(), True),
                      StructField('layer',StringType(), True),
                      StructField('source',StringType(), True),
                      StructField('table_name',StringType(), True),
                      StructField('check_type',StringType(), True),
                    StructField('DQM_Type',StringType(), True),
                    StructField('DQM_On',StringType(), True),
                    StructField('observed_value',StringType(), True),
                    StructField('difference',StringType(), True),
                    StructField('run_time',StringType(), True),
                    StructField('time_taken',StringType(), True),
                    StructField('qc_run',StringType(), True),
                    StructField('qc_run_error',StringType(), True),
                    StructField('qc_status',StringType(), True),
                    StructField('qc_error',StringType(), True),
                    StructField('threshold_status',StringType(), True),
                    StructField('criticality',StringType(), True),
                    StructField('alert_flag',StringType(), True)])
    self.keys=['batch_id',
               'run_id',
               'layer',
               'source',
               'table_name',
               'check_type',
               'DQM_Type',
               'DQM_On',
               'observed_value',
               'difference',
               'run_time',
               'time_taken',
               'qc_run',
               'qc_run_error',
               'qc_status',
               'qc_error',
               'threshold_status',
               'criticality',
               'alert_flag']
    try:
      #_=spark.read.format('delta').load(qc_table)
      self.qc_table_name=self.fn_getTableName(qc_table)
      self.qc_data= self.fn_readData(qc_table,'orc','full')
      self.qc_view_name="DQM_"+self.qc_table_name+"_view"
      print({'qc_table_name':self.qc_table_name,'qc_table_view':self.qc_view_name})
      print("Qc table is already present ")
    except:
      print("Qc table is not exits. Creating new one")
      df = self.spark.createDataFrame(data=[],schema = self.schema)
      df.write.format('orc').save(qc_table)
      self.qc_table_name=self.fn_getTableName(qc_table)
      self.qc_data= self.fn_readData(qc_table,'orc','full')
      self.qc_view_name="DQM_"+self.qc_table_name+"_view"
      print({'qc_table_name':self.qc_table_name,'qc_table_view':self.qc_view_name})
    
  def get_db_utils(self,spark):
      dbutils = None
      if spark.conf.get("spark.databricks.service.client.enabled") == "true":
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
      else:
        import IPython
        dbutils = IPython.get_ipython().user_ns["dbutils"]
      return dbutils
      
  def fn_get_qc_status(self, value, condition,criticality):
    #value= eval(str(value)) if str(value).isdigit() else str(value)
    #print(" Value ==>",type(value)," value=",value)
    status=''
    rgb_value=''
    alert_flag='N'
    if condition!='':
      _locals = locals()
      exec(condition,globals(), _locals)
      status = _locals['status']
      if status!='GREEN':
        #expected=condition.replace('"Pass"','').replace('"fail"','').replace('if','').replace('else','')
        expected=condition[:condition.find(':')].replace('if','')
        error=f"Status is {status}. ('{value}') records are not pass for the condition ('{expected}')"
        rgb_value=status
        status='fail'
        if criticality == 'Y':
          alert_flag='Y'
      else:
        rgb_value=status
        status='success'
        error=None
    else:
      status,rgb_value,error=None,None,None
      
    #print(status,'\n',rgb_value,'\n',error)
    return status,rgb_value,error,alert_flag
  
  def fn_getTableName(self,table_path):
    table_path=table_path
    return table_path.split('/')[-2] if table_path.split('/')[-1]=='' else table_path.split('/')[-1]
  
  def fn_write_error_log(self,batch_id,run_id,layer,table_name,column_name,Dqm_type,data):
    table_data = create_map(list(chain(*((lit(name), col(name).cast('string')) for name in data.columns)))).alias("table_data")
    
    data=data.withColumn('batch_id',lit(batch_id)).withColumn('run_id',lit(run_id)).withColumn('layer',lit(layer)).withColumn('table_name',lit(table_name)).withColumn('column_name',lit(column_name)).withColumn('Dqm_type',lit(Dqm_type))
    data.select('batch_id','run_id','layer','table_name','column_name','Dqm_type',table_data).write.mode('append').save('/mnt/cdw_maestrodl/lob/damcoffw/poc/test_p/test_error_log_table')
    return 1
  
  def get_partition(self,path,size=0,cnt=0):
    dutils=DBUtils(SparkSession.getActiveSession())
    if size>0:
      return path
    elif cnt>6:
      return path
    else:
      path=dutils.fs.ls(path)[-1].path
      size=dutils.fs.ls(path)[-1].size
      cnt+=1
      return self.get_partition(path=path,size=size,cnt=cnt)
  
  def fn_readData(self,table_path,format,read_type):
    table_name=self.fn_getTableName(table_path).split('.')[0]
    #print(table_name)
    if read_type =='current':
      file_path=self.get_partition(table_path)
    else:
      file_path=table_path
    data=self.spark.read.format(format).option("header",True).load(file_path)
    data.cache()
    data.createOrReplaceTempView("DQM_"+table_name+"_view")
    return data
  
  def fn_send_dq_alert(self,to_list:str,subject:str,mail_body:str):
    mailobj={"mail_body": mail_body,"mail_list": to_list,"mail_subject": subject}
    mailobj=eval(str(mailobj))
    url=f'https://prod-65.westeurope.logic.azure.com:443/workflows/cd07722c6ef84aea99fd0aedba50a24e/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=XmhNmXXri-aCVj9Clcon3qTZNkci0mfsTg3mFuAQH-0'
    x = requests.post(url, json = mailobj, headers={'Content-Type':'application/json'})
    #print(x.status_code)
    
  def fn_generate_mail_body(self,check_type,check_name,column,value,end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag):
    mail_body=f'''Hi Team, <br/> Below are the detail of alert summary <br/> <table border=1>
  <thead><tr><th>Indicators</th><th>Value</th></tr></thead>
  <tbody>
    <tr><td>batch_id</td><td>{self.batch_id}</td></tr>
    <tr><td>run_id</td><td>{self.run_id}</td></tr>
    <tr><td>layer</td><td>{self.layer}</td></tr>
    <tr><td>source</td><td>{self.source}</td></tr>
    <tr><td>table_name</td><td>{self.table_name}</td></tr>
    <tr><td>check_type</td><td>{check_type}</td></tr>
    <tr><td>Check_Name</td><td>{check_name}</td></tr>
    <tr><td>column</td><td>{column}</td></tr>
    <tr><td>value</td><td>{str(value)}</td></tr>
    <tr><td>qc_run_time</td><td>{str(end_time)}</td></tr>
    <tr><td>qc_time_taken</td><td>{str(end_time-start_time)}</td></tr>
    <tr><td>qfn_status</td><td>{qfn_status}</td></tr>
    <tr><td>qfn_error</td><td>{qfn_error}</td></tr>
    <tr><td>qc_status</td><td>{qc_status}</td></tr>
    <tr><td>qc_error</td><td>{qc_error}</td></tr>
    <tr bgcolor="{rgb_value}"><td>Severity</td><td>{rgb_value}</td></tr>
    <tr><td>criticality</td><td>{criticality}</td></tr>
    <tr><td>alert_flag</td><td>{alert_flag}</td></tr>
  </tbody>
</table><br/><br/> Thanks''';
    return mail_body
  
  def fn_getMessage(self,message):
    self.message=f"INFO : {datetime.datetime.now()} : {message}"
    return self.message
  
  def fn_writeData(self,data):
    logdata=dict(zip(self.keys,data))
    self.spark.createDataFrame(data=[logdata],schema=self.schema).write.format('orc').mode('append').save(self.qc_table)
    #print('\r\n--------------\r\n',logdata,'\r\n-----------------\r\n')
    return self.fn_getMessage("Log Saved Successfully")
  
  def fn_checkCount(self,check_type,column=None):
    start_time=datetime.datetime.now()
    #table_name=self.fn_getTableName(table_path)
    #data= self.fn_readData(table_path,format)
    if column==None:
      count=self.data.count()
      column='*'
    else:
      count=self.spark.sql(f"select count({column}) from {self.view_name}").take(1)
      count=count[0][0]
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkCount",column,str(count),'',str(end_time),str(end_time-start_time),'success','']
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkDuplicate(self,column,filtercondition,rgb_condition,check_type,criticality):
    start_time=datetime.datetime.now()
    #table_name=self.fn_getTableName(table_path)
    #data= self.fn_readData(table_path,format)
    count=self.data.count()
    distinctcount=self.data.select(column).distinct().count()
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,"checkDuplicate",column,str(count-distinctcount),'',str(end_time),str(end_time-start_time),'success','']
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkCountDistinct(self,column,filtercondition,rgb_condition,check_type,criticality):
    start_time=datetime.datetime.now()
    if column.replace('`','') not in [scol for scol in self.primary_key.split(',')] and column != '`*`' and column.startswith('`'):
        select_list=[scol for scol in self.primary_key.split(',')].append(column.replace('`',''))
    else:
        select_list=[scol for scol in self.primary_key.split(',')]
        
        
    #table_name=self.fn_getTableName(table_path)
    #data= self.fn_readData(table_path,format)
    sql="select a.* from  "+self.view_name+" a inner join (select `"+column+"`,count(`"+column+"`) from "+self.view_name+" group by `"+column+"` having count(`"+column+"`)>1) b on a.`"+column+"`=b.`"+column+"`"
    distinctcount=self.data.select(column).distinct().count()
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,"checkCountDistinct",column,str(distinctcount),'',str(end_time),str(end_time-start_time),'success','']
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkMin(self,column,filtercondition,rgb_condition,check_type,criticality):
    start_time=datetime.datetime.now()
    #table_name=self.fn_getTableName(table_path)
    #data= self.fn_readData(table_path,format)
    min=self.data.agg({column:'min'}).take(1)[0][0]
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,"checkMinimum",column,str(min),'',str(end_time),str(end_time-start_time),'success','']
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  
  def fn_checkMax(self,column,filtercondition,rgb_condition,check_type,criticality):
    start_time=datetime.datetime.now()
    #table_name=self.fn_getTableName(table_path)
    #data= self.fn_readData(table_path,format)
    max=self.data.agg({column:'max'}).take(1)[0][0]
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,"checkMaximum",column,str(max),'',str(end_time),str(end_time-start_time),'success','']
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkAverage(self,column,filtercondition,rgb_condition,check_type,criticality):
    start_time=datetime.datetime.now()
    #table_name=self.fn_getTableName(table_path)
    #data= self.fn_readData(table_path,format)
    avg=self.data.agg({column:'avg'}).take(1)[0][0]
    qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(avg,rgb_condition,criticality)
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,"checkAverage",column,str(avg),'',str(end_time),str(end_time-start_time),'success','',qc_status,qc_error,rgb_value,criticality,alert_flag]
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkDatatype(self,column,filtercondition,rgb_condition,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,missing_data,missing,count='','','','',None,'success','','','',''
    start_time=datetime.datetime.now()
    
    try:
      datatype=[dtype for name, dtype in self.data.dtypes if name.replace('`','').lower() == column.replace('`','').lower()][0]
      qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(str(datatype),rgb_condition,criticality)
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:500],'fail'
      
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkDatatype",column,str(datatype),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkDatatype",column,str(datatype),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      #self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkDatatype",missing_data)
      
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkLength(self,column,filtercondition,rgb_condition,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,missing_data,missing,count='','','','',None,'success','','','',''
    start_time=datetime.datetime.now()
    
    try:
      
      if column.replace('`','') not in [scol for scol in self.primary_key.split(',')] and column != '`*`' and column.startswith('`'):
        select_list=[scol for scol in self.primary_key.split(',')].append(column.replace('`',''))
      else:
        select_list=[scol for scol in self.primary_key.split(',')]
        
      missing_data=self.data.filter(filtercondition).select(select_list)
      missing=missing_data.count()
      qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(int(missing),rgb_condition,criticality)
      print(qc_status,qc_error)
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:500],'fail'
      

    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkLength",column,str(missing),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkLength",column,str(missing),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkLength",missing_data)
      
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkValueRange(self,column,filtercondition,rgb_condition,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,missing_data,missing,count='','','','',None,'success','','','',''
    start_time=datetime.datetime.now()
    
    try:
      
      if column.replace('`','') not in [scol for scol in self.primary_key.split(',')] and column != '`*`' and column.startswith('`'):
        select_list=[scol for scol in self.primary_key.split(',')].append(column.replace('`',''))
      else:
        select_list=[scol for scol in self.primary_key.split(',')]
        
      missing_data=self.data.filter(filtercondition).select(select_list)
      missing=missing_data.count()
      qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(int(missing),rgb_condition,criticality)
      print(qc_status,qc_error)
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:500],'fail'
      
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkValueRange",column,str(missing),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkValueRange",column,str(missing),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkValueRange",missing_data)
      
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkCompleteness(self,column,filtercondition,rgb_condition,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,missing_data,missing,count='','','','',None,'success','','','',''
    start_time=datetime.datetime.now()
    try:
      
      if column.replace('`','') not in [scol for scol in self.primary_key.split(',')] and column != '`*`' and column.startswith('`'):
        select_list=[scol for scol in self.primary_key.split(',')].append(column.replace('`',''))
      else:
        select_list=[scol for scol in self.primary_key.split(',')]
        
      count=self.spark.sql(f"select count({column}) from {self.view_name}").take(1)
      count=count[0][0]
      #print(filtercondition)
      missing_data=self.data.filter(filtercondition).select(select_list)
      missing=missing_data.count()
      missing=missing/count
      print('missing:',missing)
      print('count:',count)
      qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(int(missing),rgb_condition,criticality)
      print(qc_status,qc_error)
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:500],'fail'

    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkCompleteness",column,str(missing),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkCompleteness",column,str(missing),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkCompleteness",missing_data)
    
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkNegative(self,column,filtercondition,rgb_condition,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,missing_data,missing='','','','','','','','',''
    start_time=datetime.datetime.now()
    try:
      
      if column.replace('`','') not in [scol for scol in self.primary_key.split(',')] and column != '`*`' and column.startswith('`'):
        select_list=[scol for scol in self.primary_key.split(',')].append(column.replace('`',''))
      else:
        select_list=[scol for scol in self.primary_key.split(',')]
        
        
      missing_data=self.data.filter(filtercondition).select(select_list)
      missing=missing_data.count()
      qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(int(missing),rgb_condition,criticality)
      print(qc_status,qc_error)
      qfn_status='Success'
      qfn_error=None
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:100],'fail'
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkNegative",column,str(missing),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkNegative",column,str(missing),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkNegative",missing_data)
    
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkMissingValue(self,column,filtercondition,rgb_condition,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,missing_data,missing='','','','',None,'success','','',''
    start_time=datetime.datetime.now()
    try:
      
      if column.replace('`','') not in [scol for scol in self.primary_key.split(',')] and column != '`*`' and column.startswith('`'):
        select_list=[scol for scol in self.primary_key.split(',')].append(column.replace('`',''))
      else:
        select_list=[scol for scol in self.primary_key.split(',')]
      
      
      missing_data=self.data.filter(filtercondition).select(select_list)
      missing=missing_data.count()
      qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(int(missing),rgb_condition,criticality)
      print(qc_status,qc_error)
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:100],'fail'
      

    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkMissingValue",column,str(missing),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkMissingValue",column,str(missing),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkMissingValue",missing_data)
    
    info=self.fn_writeData(data)
    #print(info)
    return info
  
  def fn_checkValueTrend(self,column,filtercondition,rgb_condition,window_parameter,check_type,criticality):
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,avg,value='','','','','','','','',''
    start_time=datetime.datetime.now()
    print("===============================")
    print(column,filtercondition,rgb_condition,window_parameter,check_type,criticality)
    print("===============================")
    try:
      sql=filtercondition.replace('?',self.view_name)
      column='*' if '(*)' in sql else column
      current=self.spark.sql(sql).take(1)
      current=current[0][0]
      print("current====>",current)
      if self.read_type == 'full':
        sql2=filtercondition.replace('?',self.view_name)
      #qc_sql=f"select coalesce(avg(observed_value),0) avg from (select observed_value From {self.qc_view_name} where layer='{self.layer}' and source='{self.source}' and table_name='{self.table_name}' and DQM_On='{column}' and DQM_Type='checkValueTrend' and threshold_status='GREEN' order by run_time desc limit {window_parameter})a"
      qc_sql=f"select coalesce(avg(observed_value),0) avg from (select observed_value From {self.qc_view_name} where layer='{self.layer}' and source='{self.source}' and table_name='{self.table_name}' and DQM_On='{column}' and DQM_Type='checkValueTrend' and threshold_status='GREEN' order by run_time desc limit {10})a"

      print(qc_sql)
      avg=self.spark.sql(qc_sql).take(1)
      avg=avg[0][0]

      print("avg====>",avg)
      if avg>0:
        value=(current-avg)/avg
        qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(float(value),rgb_condition,criticality)
        value=value*100
      else:
        value=None;
        qc_status,rgb_value,qc_error,alert_flag='success','GREEN',None,'N'


      print(qc_status,qc_error)
      qfn_status='Success'
      qfn_error=None
    except Exception as e:
      qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status=None,None,None,None,str(e)[:100],'fail'
      
    end_time=datetime.datetime.now()
    
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,"checkValueTrend",column,str(current),str(value),str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"checkValueTrend",column,str(value),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      #self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"checkValueTrend",missing_data)
      
    info=self.fn_writeData(data)
    #print(info)
    return info

  
  def fn_customQualityCheck(self,sql_query,rgb_condition,criticality,check_name="CustomCheck",check_type="CustomCheck"):
    '''
    sql_query : give sql query with table_name as '?' symbol
    example : select max(case when column>1 then 1 else 0 end) from ?
    qc_name : quality check label
    '''
    qc_status,rgb_value,qc_error,alert_flag,qfn_error,qfn_status,current,output_data,output='','','','',None,'success','','',''
    
    start_time=datetime.datetime.now()
    
    sql=sql_query.replace('?',self.view_name)
    #print(sql)
    try:
      output=self.spark.sql(sql).take(1)
      if len(output)==1:
        value=output[0][0]
        qc_status,rgb_value,qc_error,alert_flag=self.fn_get_qc_status(float(value),rgb_condition,criticality)
        output=output[0][0]
      else:
        output=None
        qfn_status='fail'
        qfn_error='Error: Multiple value return from result'
    except Exception as e:
      output=None
      qfn_status='fail'
      qfn_error='Error: Problem with SQL query : '+str(e)[:200]
      
    end_time=datetime.datetime.now()
    data=[self.batch_id,self.run_id,self.layer,self.source,self.table_name,check_type,check_name,sql_query,str(output),'',str(end_time),str(end_time-start_time),qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag]
    
    if alert_flag == 'Y':
      mail_data=self.fn_generate_mail_body(check_type,"customQualityCheck",sql_query,str(output),end_time,start_time,qfn_status,qfn_error,qc_status,qc_error,rgb_value,criticality,alert_flag)
      to_list=str('mohammad.hamza@maersk.com;santosh.birje@maersk.com;ankur.abhishek@maersk.com')
      subject=f"{rgb_value} alert from DQ for {self.source} {self.layer} layer and {self.table_name} object"
      
      self.fn_send_dq_alert(to_list=to_list,subject=subject,mail_body=mail_data)
      #self.fn_write_error_log(self.batch_id,self.run_id,self.layer,self.table_name,column,"customQualityCheck",missing_data)

    info=self.fn_writeData(data)
    #print(info)
    return info
